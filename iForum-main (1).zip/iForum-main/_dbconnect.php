<?php
// Script To connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$database = "iForums";

$con = mysqli_connect($servername,$username,$password,$database);




?>